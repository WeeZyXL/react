//importar tela Home
import Home from "./src/telas/Home";

export default function App() {
  return (
    <Home />
  );
}


