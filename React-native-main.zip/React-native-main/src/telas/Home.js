//1° passo - Importar o React
import React from "react";

//2° passo - Importar o componentes da tela
import {Image, Text, TextInput, TouchableOpacity, SafeAreaView, StyleSheet} from 'react-native';

//3° passo - Criar a função que cria a tela
export default function Home(){
    return (
        <SafeAreaView>
            <Text> Projeto IMC </Text>

            <TextInput placeholder='Altura'/>
            
            <TextInput placeholder='Peso'/>

            <TouchableOpacity>
                <Text>Calcular</Text>
            </TouchableOpacity>

            <Text>IMC: 25.00</Text>

        </SafeAreaView>
    )
}
